"""
Ultra-Optimized Bedrock Chat - Super-optimized AWS Bedrock chat interface in 50 lines
"""

from bedrock_chat.__version__ import __version__

__all__ = ["__version__"]